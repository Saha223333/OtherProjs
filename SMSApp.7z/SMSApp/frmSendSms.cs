﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SMS;

namespace SMSApp
{
    public partial class frmSendSms : Form
    {
        public frmSendSms()
        {
            InitializeComponent();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            SendSMS obj = new SendSMS(txtMessageCenter.Text,txtPort.Text);
            obj.SendMessage(txtTo.Text, txtMessage.Text);

            //ReceiveSMS recieve = new ReceiveSMS();
            //recieve.receiveSMS();
        }
    }
}
