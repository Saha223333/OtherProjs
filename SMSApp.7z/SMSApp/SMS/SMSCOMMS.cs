

//Developed by  : Shefeek Jinnah
//For Assistance visit  : http://www.shefeekj.com
//or mail : shefeekj@shefeekj.com

using System;
using System.IO.Ports;
using System.Threading;
using System.Text;

namespace SMS
{
    public class SMSCOMMS
    {

        private SerialPort SMSPort;
        private Thread ReadThread;
        public static string pdu;
        //Constructor
        public SMSCOMMS(ref string COMMPORT)
        {
            SMSPort = new SerialPort();
            SMSPort.PortName = COMMPORT;
            SMSPort.BaudRate = 9600;
            SMSPort.Parity = Parity.None;
            SMSPort.DataBits = 8;
            SMSPort.StopBits = StopBits.One;
            SMSPort.Handshake = Handshake.RequestToSend;
            SMSPort.DtrEnable = true;
            SMSPort.RtsEnable = true;
            SMSPort.NewLine = System.Environment.NewLine;
            ReadThread = new Thread(
                new System.Threading.ThreadStart(readSMS));

            pdu = string.Empty;


        }

        //Open the port
        public void Open()
        {
            try
            {
                if (SMSPort.IsOpen == false)
                {
                    SMSPort.Open();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        //Close the Port
        public void Close()
        {
            try
            {
                if (SMSPort.IsOpen == true)
                {
                    SMSPort.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        //Send message in pdu format
        public void SendPDU(string SMSMessage, int length)
        {
            try
            {
                string MyMessage = SMSMessage.Trim();
                string cmd;
                string port = SMSPort.PortName;
                char ch = '"';
                int lengthOfMessage;
                if (length % 7 > 0)
                {
                    lengthOfMessage = ((length + 13) - (length / 7));

                }
                else
                {
                    lengthOfMessage = (((length + 13) - (length / 7)) + 1);

                }

                if (SMSPort.IsOpen == true)
                {
                    string b;
                    ASCIIEncoding ascii = new ASCIIEncoding();

                    cmd = "AT+CMGS=" + lengthOfMessage + "";
                    SMSPort.WriteLine(cmd);

                    byte[] RXBuffer = new byte[SMSPort.ReadBufferSize + 1];
                    SMSPort.Read(RXBuffer, 0, SMSPort.ReadBufferSize);

                    b = Encoding.ASCII.GetString(RXBuffer, 0, RXBuffer.Length);

                    cmd = string.Empty;
                    cmd = "" + MyMessage + char.ConvertFromUtf32(26) + "";
                    SMSPort.WriteLine(cmd);

                    SMSPort.Read(RXBuffer, 0, SMSPort.ReadBufferSize);

                    b = Encoding.ASCII.GetString(RXBuffer, 0, RXBuffer.Length);

                    string x = string.Empty;

                    b = Encoding.ASCII.GetString(RXBuffer, 0, RXBuffer.Length);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        //Read the port

        public void readSMS()
        {
            try
            {
                Open();
                string cmd;
                char ch = '"';
                ASCIIEncoding ascii = new ASCIIEncoding();
                cmd = "AT+CPMS=" + ch + "ME" + ch + "";
                SMSPort.WriteLine(cmd);
                Thread.Sleep(1000);
                byte[] RXBuffer = new byte[SMSPort.ReadBufferSize + 1];
                SMSPort.Read(RXBuffer, 0, SMSPort.ReadBufferSize);
                string x = Encoding.ASCII.GetString(RXBuffer, 0, RXBuffer.Length);
                Thread.Sleep(1000);
                cmd = "AT+CMGR=5";
                SMSPort.WriteLine(cmd);
                cmd = "" + char.ConvertFromUtf32(13) + "";


                // SMSPort.Read(RXBuffer, 0, SMSPort.ReadBufferSize);
                //string  b = Encoding.ASCII.GetString(RXBuffer, 0, RXBuffer.Length);

                pdu = SMSPort.ReadLine();

                pdu = SMSPort.ReadLine();
                if (pdu == "+CMS ERROR: 500")
                {
                    pdu = string.Empty;
                }
                else
                {
                    pdu = SMSPort.ReadLine();
                    pdu = pdu.Trim();
                }

                cmd = "AT+CMGD=1";
                SMSPort.WriteLine(cmd);
                Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}