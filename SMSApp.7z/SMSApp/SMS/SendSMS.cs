//Developed by  : Shefeek Jinnah
//For Assistance visit  : http://www.shefeekj.com
//or mail : shefeekj@shefeekj.com


//The Function of this class is to generate PDU message from the available data

//Input to this class = Message Centre NUmber,Receiver Number,Message in text format
//Output  = SMS in pdu format
//Functions in this class
//1.SendMessage(string receiver, string msg)  ---->Entry point to this class
//2 .GeneratePdu(string receiver, string msg) ----> Generates SMS in PDU format using the other functions
//3.MessageToHex(string message)------>Function to convert message to Hexadecimal 8-bit octets
//4.getOctet(string receiver)-------->Function to Encrypt Receiver and Message Centre Number(SemiOctet)
//5.SendToSMSEngine(string pdu,int length)----->Exit point from this class.It passes the final SMS in the PDU format to the SMS Engine

using System;
using System.Collections.Generic;
using System.Text;

namespace SMS
{
    class SendSMS
    {
        SMSCOMMS SMSEngine;
        string messageCenter = string.Empty; //"919022000500";
        string portName = string.Empty; //"COM1";

        public SendSMS(String messageCenter,String portName)
        {
            this.messageCenter = messageCenter;
            this.portName = portName;
        }

        //Entry point to this class
        public void SendMessage(string receiver, string msg)
        {
            int length = msg.Length;
            try
            {
                string pdu;
                pdu = GeneratePdu(receiver, msg);

                //obj.receiveSMS(pdu);

                SendToSMSEngine(pdu,length);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        //The function passes the final message in the pdu format to the SMS Engine

        public void SendToSMSEngine(string pdu,int length)
        {
            string x = portName;
            SMSEngine = new SMSCOMMS(ref x);
            //ensure that port is closed previously
            SMSEngine.Close();
            SMSEngine.Open();
            SMSEngine.SendPDU(pdu,length);
            SMSEngine.Close();
        }



        //Function to generate PDU
        public string GeneratePdu(string receiver, string msg)
        {
            string pdu=string.Empty;
            
            try
            {
                string meta = "0791";
                string messagecentre = getOctet(messageCenter);
                string sendernum = getOctet(receiver);
                string hexMessage = MessageToHex(msg);
                hexMessage = hexMessage.Trim();
                string hexLength = (msg.Length).ToString("X");
                if (hexLength.Length == 1)
                {

                    hexLength = "0" + hexLength + "";
                }
                pdu = meta + messagecentre + "01000C91" + sendernum + "0000" + hexLength + hexMessage + "";
                pdu = pdu.Trim();
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return pdu;
        }




        //Function to convert message to Hexadecimal 8-bit octets

        public string MessageToHex(string message)
        {
            string hexString=string.Empty;
            try
            {
                string msg = message;
                int[] a = new int[msg.Length * 8];
                string[] splitstring = new string[msg.Length];
                string[] hexValue = new string[1000];
                int pos = 0;


                //Split the Message
                for (int i = 0; i < msg.Length; i++)
                {
                    splitstring.SetValue(msg.Substring(i, 1), i);
                }


                //COnvert to Binary
                string[] bin = new string[splitstring.Length];
                for (int i = 0; i < splitstring.Length; i++)
                {
                    a[i] = Convert.ToInt32(Convert.ToChar(splitstring[i].ToString()));
                    bin[i] = Convert.ToString(a[i], 2);
                    if (bin[i].Length == 6)
                    {
                        bin[i] = "0" + bin[i].ToString() + "";
                    }
                }

                
                //Convert to octect
                string[] oct = new string[100];
                int count = 1;
                for (int i = 0; i < bin.Length - 1; i++)
                {
                    string[] sub = new string[bin[i].Length];

                    //Take i+1 th binary value 

                    for (int j = 0; j < bin[0].Length; j++)
                    {
                        sub.SetValue(bin[i + 1].Substring(j, 1), j);
                    }
                    string concat = string.Empty;

                    //Make the string to concatanate

                    for (int k = sub.Length - count; k < sub.Length; k++)
                    {
                        concat = "" + concat + sub[k].ToString() + "";
                    }

                    string octal = string.Empty;
                    octal = "" + octal + concat + "";


                    //COncatanation

                    for (int l = 0; l < bin[i].Length - (count - 1); l++)
                    {
                        sub.SetValue(bin[i].Substring(l, 1), l);
                        octal = "" + octal + sub[l].ToString() + "";
                    }
                    hexValue[pos] = "" + octal + "";

                    pos++;
                    count++;
                    if (count == 8)
                    {
                        count = 1;
                        i = i + 1;

                    }

                    //Last COlumn

                    octal = string.Empty;
                    if (i == bin.Length - 2)
                    {
                        for (int l = 0; l < bin[i].Length - (count - 1); l++)
                        {
                            sub.SetValue(bin[i + 1].Substring(l, 1), l);

                            octal = "" + octal + sub[l].ToString() + "";
                        }

                        hexValue[pos] = "" + octal + "";
                    }
                }

                //Convert to Hexadecimal
                for (int i = 0; i < pos; i++)
                {
                    int decimalval = Convert.ToInt32(hexValue[i].ToString(), 2);
                    string h = decimalval.ToString("X");
                    if (h.Length == 1)
                    {
                        h = "0" + h + "";
                    }
                    hexString = " " + hexString + h + "";
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return hexString;
        }




        //Function to Encrypt Receiver and Message Centre Number(SemiOctet)
        public string getOctet(string receiver)
        {
            string[] receive = new string[receiver.Length + 1];
            string returnreceive = string.Empty;
            try
            {
                
                if (receiver.Length % 2 == 0)
                {
                    for (int i = 0; i < receiver.Length; i++)
                    {
                        receive.SetValue(receiver.Substring(i, 1), i);
                    }
                }
                else
                {
                    for (int i = 0; i < receiver.Length; i++)
                    {
                        receive.SetValue(receiver.Substring(i, 1), i);
                    }
                    receive[receive.Length - 1] = "F";
                }

                for (int i = 0; i < receive.Length; i++)
                {
                    string swap;
                    swap = receive[i].ToString();
                    receive[i] = receive[i + 1].ToString();
                    receive[i + 1] = swap;
                    i++;
                    if (i == receiver.Length - 1)
                    {
                        if (receiver.Length % 2 == 0)
                        {
                            i++;
                        }
                    }
                }
                for (int i = 0; i < receive.Length; i++)
                {
                    returnreceive = "" + returnreceive + receive[i].ToString() + "";

                    if (i == receiver.Length - 1)
                    {
                        if (receiver.Length % 2 == 0)
                        {
                            i++;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnreceive;
        }
    }
}
