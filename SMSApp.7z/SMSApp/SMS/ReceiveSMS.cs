


//Developed by  : Shefeek Jinnah
//For Assistance visit  : http://www.shefeekj.com
//or mail : shefeekj@shefeekj.com



using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
namespace SMS
{
    //The function of this class is to read message from a mobile and decrypt it
    
    class ReceiveSMS
    {
        SMSCOMMS SMSEngine;
        SendSMS obj = new SendSMS("","COM1");
        public static string[] messageDetails;

        public ReceiveSMS()
        {
            messageDetails = new string[3];
            messageDetails[0] = "";
            messageDetails[1] = "";
            messageDetails[2] = "";
        }
        //This function is the entry point to this class.All other functions are called from this class
        public void receiveSMS()
        {
            try
            {
                messageDetails[0] = "";
                messageDetails[1] = "";
                messageDetails[2] = "";
                SMSCOMMS.pdu = string.Empty;
                string pdu;
                string x = "COM20";
                SMSEngine = new SMSCOMMS(ref x);
                SMSEngine.Open();               // Open the Port in which mobile is connected
                SMSEngine.readSMS();      // Read SMS From Mobile through Port
                SMSEngine.Close();              // Close Port
                if (SMSCOMMS.pdu== "")
                {
                }
                else
                {
                    messageDetails[0] = decryptNumber(extractMessageCentre(SMSCOMMS.pdu));       // Decrypt Message Centre Number
                    messageDetails[1] = decryptNumber(extractSenderNumber(SMSCOMMS.pdu));        // Decrypt Sender Number
                    messageDetails[2] = DecryptMessage(ExtractMessageFromPdu(SMSCOMMS.pdu));      // Decrypt Message
                }
                }
            catch (Exception ex)
            {
            }
        }


        //The function is to extract Message centre number from PDU

        public string extractMessageCentre(string pdu)
        {
            string[] messageDetails = new string[3];
            string extractedNumber = string.Empty;
            try
            {
                for (int i = 4; i < 16; i++)
                {
                    extractedNumber = "" + extractedNumber + pdu.Substring(i, 1) + "";

                }
            }
            catch (Exception ex)
            {
            }
            return extractedNumber;
        }

        //The function is to extract   sender number from the PDU

        public string extractSenderNumber(string pdu)
        {
            string extractedNumber = string.Empty;
            try
            {
                for (int i = 22; i < 34; i++)
                {
                    extractedNumber = "" + extractedNumber + pdu.Substring(i, 1) + "";

                }
            }
            catch (Exception ex)
            {
            }
            return extractedNumber;
        }

        //The function is to Decrypt a number from PDU (Message Centre Number & Sender Number)

        public string decryptNumber(string number)
        {
            string[] receive = new string[number.Length + 1];
            string returnreceive = string.Empty;
            try
            {

                for (int i = 0; i < number.Length; i++)
                {
                    receive.SetValue(number.Substring(i, 1), i);
                }


                for (int i = 0; i < receive.Length; i++)
                {
                    string swap;
                    swap = receive[i].ToString();
                    receive[i] = receive[i + 1].ToString();
                    receive[i + 1] = swap;
                    i++;
                    if (i == number.Length - 1)
                    {
                        if (number.Length % 2 == 0)
                        {
                            i++;
                        }
                    }
                }
                for (int i = 0; i < receive.Length; i++)
                {
                    returnreceive = "" + returnreceive + receive[i].ToString() + "";
                }
            }
            catch (Exception ex)
            {

            }
            return returnreceive;
        }


        //The Function is to extract Message in the encrypted format from the PDU

        public string ExtractMessageFromPdu(string pdu)
        {
            string msg = string.Empty;
            try
            {
                for (int i = 54; i < pdu.Length; i++)
                {
                    msg = "" + msg + pdu.Substring(i, 1);
                }
            }
            catch (Exception ex)
            {
            }
            return msg;
        }

        // The two functions below decrypts message extracted from the PDU

        public string DecryptMessage(string msg)
        {
            int j = 0;
            string[] bin = new string[1000];
            try
            {
                string message = msg.Trim();
                int count = 1, pos = 0;
                string[] hexInput = new string[(msg.Length) / 2];
                string[] splitstring = new string[8];
                string[] binSeven = new string[100];
                string concat = string.Empty;
                string temp = string.Empty;

                

                //Split entire string into pairs

                for (int i = 0; i < message.Length - 1; i++)
                {
                    hexInput[j] = msg.Substring(i, 2);
                    j++;
                    i++;

                }

                //Convert each pair into 8  bit binary

                for (int i = 0; i < j; i++)
                {

                    bin[i] = Convert.ToString(Convert.ToInt32(hexInput[i], 16), 2);

                    while (bin[i].Length != 8)
                    {
                        bin[i] = "0" + bin[i] + "";
                    }

                }
            }
            catch (Exception ex)
            {
            }
            //Passes a string array containing 8 bit binary values to the next function

           return CovertFromHex(bin, j);



        }
        //The input to this function is a string array containing 8 bit binary values equivalent to hex values

        public string CovertFromHex(string[] hexValue, int length)
        {
            string message = string.Empty;
            try
            {
                int count = 1, pos = 0;
                string[] hexInput = new string[hexValue.Length];
                string[] splitstring = new string[8];
                string[] bin = new string[1000];
                string concat = string.Empty;
                string temp = string.Empty;
                for (int i = 0; i < length; i++)
                {

                    string extract = hexValue[i].ToString();

                    if (extract != string.Empty)
                    {
                        string[] x = new string[count];
                        for (int k = 0; k < extract.Length; k++)
                        {

                            if (k >= count)
                            {
                                concat = "" + concat + extract.Substring(k, 1) + "";
                            }
                            else
                            {

                                x[k] = extract.Substring(k, 1);
                            }
                        }
                        bin[pos] = "" + concat + temp + "";
                        temp = string.Empty;
                        concat = string.Empty;
                        count = count + 1;
                        for (int j = 0; j < x.Length; j++)
                        {
                            temp = "" + temp + x[j].ToString() + "";
                        }
                        pos++;
                        if (count == 8)
                        {
                            count = 1;
                            bin[pos] = temp;
                            temp = string.Empty;
                            pos++;

                        }
                    }


                }
                bin[pos - 1] = "" + temp + bin[pos - 1].ToString() + "";


                //Binary to ASCII
                string[] asciiVal = new string[pos];
                for (int i = 0; i < pos; i++)
                {
                    asciiVal[i] = Convert.ToInt64(bin[i].ToString(), 2).ToString();

                }

                for (int i = 0; i < pos; i++)
                {

                    message = "" + message + char.ConvertFromUtf32(Convert.ToInt32(asciiVal[i].ToString()));
                }
            }
            catch (Exception ex)
            {
            }
            return message;

        }

    }
    }

